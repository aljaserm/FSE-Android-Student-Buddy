package com.processfast.csce492;

import android.app.Activity;

public class ModifyAssignmentTypeActivity extends Activity {

}

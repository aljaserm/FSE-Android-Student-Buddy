package com.processfast.csce492;

import android.app.Activity;
import android.os.Bundle;

public class ModifyGradeActivity extends Activity {
	@Override 
    public void onCreate(Bundle savedInstanceState) { 
          super.onCreate(savedInstanceState); 
          this.setContentView(R.layout.modifygrade);  
    } 
}
